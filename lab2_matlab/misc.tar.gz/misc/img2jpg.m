function img2jpg( image )
i=imread(image);
[path,name,ext] = fileparts(image);
imwrite(i,[name,'.jpg']);
end