cd /home/vision/misc
matriz=dir('*.tiff');
for i=1:length(matriz)
    file=matriz(i).name;
    img2jpg(file);
end